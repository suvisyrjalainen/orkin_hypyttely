function preload() {
  taustakuva = loadImage('tower.png');
  orkkikuva = loadImage('orkki.png');
}


function setup() {
   createCanvas(windowWidth, windowWidth / 3 );
}

function draw() {
  var korkeus = windowWidth / 3;
  leveys = windowWidth;
  image(taustakuva, 0, 0,  leveys, korkeus);
  image(orkkikuva, 0, korkeus / 2, 50, 50)
  square(leveys / 2, korkeus - 50 , 50, 20, 15, 15, 0, 0);
}

function windowResized(){
  resizeCanvas(windowWidth, windowWidth / 3);
  image(taustakuva, 0, 0, windowWidth, windowWidth / 3);
}
